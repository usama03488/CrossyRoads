using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obs_spawner : MonoBehaviour
{
    public GameObject Obj;
    public float X_pos;
    public float Delay;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Spawncaller", 2f, Delay);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyUp(KeyCode.Space))
        {
            transform.position = new Vector3(transform.position.x,transform.position.y,transform.position.z-3f);


        }
    }
    void Spawncaller()
    {
        float r = Random.Range(-7f, 7f);
  
        Instantiate(Obj, new Vector3(X_pos,transform.position.y,transform.position.z), Obj.transform.rotation);
    }
}
