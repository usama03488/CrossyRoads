using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody rb;
    public bool Isground;
    private Vector3 pos;
    public GameObject[] grounds;
    private float speed = 10f;
    private float positionz = 6f;
    private float positionX = 15f;

    // Start is called before the first frame update
    void Start()
    {
        rb= GetComponent<Rigidbody>();
        Isground = true;
        pos=gameObject.transform.position;
        Invoke("GroundSpawner", 0f);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyUp(KeyCode.Space) && Isground)
        {
            rb.AddForce(Vector3.up * 300);
            Isground=false;
            for(int i = 0; i < grounds.Length; i++)
            {
         
           //   grounds[i].transform.position =new Vector3(grounds[i].transform.position.x,grounds[i].transform.position.y,grounds[i].transform.position.z-3f);
            }
        }
      
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            Isground = true;
        }
        else if (collision.gameObject.CompareTag("Obstacles"))
        {
            Destroy(gameObject);
            Destroy(collision.gameObject); 
            Isground = false;
        }
    }
    void GroundSpawner()
    {
        for (int i = 0; i < grounds.Length; i++, positionz=positionz+3f)
        {
            Instantiate(grounds[i], new Vector3(positionX, 0, positionz), grounds[i].transform.rotation);
        }
    }
}
